import {SelectionModel} from '@angular/cdk/collections';
import {Component, OnInit} from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import { TasksService } from '../services/tasks.service';
import { TasksList } from '../services/tasks.service';


/**
 * @title Table with selection
 */
@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.scss']
})
export class TasksComponent implements OnInit {
  displayedColumns: string[] = ['select', 'taskID', 'taskTitle', 'actions'];
  dataSource = new MatTableDataSource<TasksList>();
  selection = new SelectionModel<TasksList>(true, []);
  constructor(private tasksService: TasksService) {

  }
  ngOnInit(): void {
    this.dataSource.data = this.tasksService.taskData;
    // if(this.tasksService.getTasksList()) {
    //   this.dataSource.data =  this.tasksService.getTasksList();
    // } else {
    //   this.dataSource.data = this.tasksService.taskData;
    //   this.tasksService.updateTasks(this.tasksService.taskData);
    // }
    
  }
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  toggleAllRows() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }

    this.selection.select(...this.dataSource.data);
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: TasksList): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.taskID + 1}`;
  }

  onEdit(taskID: number) {

  }

  onDelete(taskID: number) {
    console.log(taskID);
    // let  currentData = this.dataSource.data;
    // let deleteIndex = currentData.findIndex(el => el.taskID === taskID);
    // delete currentData[deleteIndex];
    this.dataSource.data.splice(taskID, 1);
    console.log(this.dataSource.data);
    // this.dataSource.data = currentData;
    this.tasksService.updateTasks(this.dataSource.data);
  }
  
  addTask() {
    
  }
}
